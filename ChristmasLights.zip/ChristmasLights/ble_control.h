// Christmas Lights - Bluetooth control
#pragma once
#include <Arduino.h>

// Start Bluetooth and advertise as BT_NAME (see config.h).
void bleSetup();

// Fetch the next command character sent from the phone.
// Returns false when there is nothing waiting.
bool bleReadCommand(char &c);

// Update the display status the phone reads, e.g. "L3 E1 A1 B100 O1".
void bleSetStatus(const String &status);

// Update the timer status the phone reads, e.g. "T1 C1 1600 2300".
void bleSetTimerStatus(const String &status);

// Update the music quiz status the phone reads, e.g. "Q1 3/12 T5 P1 R0".
void bleSetQuizStatus(const String &status);
