// Christmas Lights - music quiz and fireplace check
//
// The lights play a tune like a level meter round the fireplace: both sides
// light from the floor up to a height set by the note's pitch (the highest
// notes reach across the top), in a colour set by the note's name.
// Each note stays lit for its length, with a short gap so repeated notes
// can be counted.

#include <Adafruit_NeoPixel.h>
#include "quiz.h"
#include "quiz_tunes.h"
#include "config.h"
#include "ble_control.h"

extern Adafruit_NeoPixel strip;

static_assert(FIRE_RIGHT + FIRE_TOP + FIRE_LEFT == LED_COUNT,
              "FIRE_RIGHT + FIRE_TOP + FIRE_LEFT must equal LED_COUNT");

// Steps up each side: the side itself plus half of the top.
static const uint8_t PATH = FIRE_RIGHT + FIRE_TOP / 2;

// ---- state ----
static uint8_t  quizSet    = QUIZ_NONE;
static uint8_t  order[32];         // tune ids in this game's random order
static uint8_t  orderCount = 0;
static uint8_t  pos        = 0;    // which tune of the game we're on
static bool     playing    = false;
static bool     sound      = false;
static bool     revealed   = false;
static uint16_t noteIdx    = 0;
static uint32_t noteStart  = 0;
static uint8_t  tuneLo = 60, tuneHi = 72;


// ---------------------------------------------------------------------
// LED positions

// LED for step s (0 = bottom) on the right-hand path: up the right, then
// along the top towards the middle.
static uint8_t rightPath(uint8_t s) { return s; }

// Same on the left: up the left side (the string's far end), then along the
// top from the left corner towards the middle.
static uint8_t leftPath(uint8_t s) {
  if (s < FIRE_LEFT) return LED_COUNT - 1 - s;
  return LED_COUNT - 1 - FIRE_LEFT - (s - FIRE_LEFT);
}

static uint32_t noteColour(uint8_t midi, bool tip) {
  uint16_t hue = (uint32_t)(midi % 12) * 65536UL / 12;
  return strip.gamma32(strip.ColorHSV(hue, tip ? 120 : 255, 255));
}

static void showNote(uint8_t midi) {
  strip.clear();
  if (!midi) return;
  float level = tuneHi > tuneLo ? (float)(midi - tuneLo) / (tuneHi - tuneLo) : 1.0f;
  uint8_t steps = 2 + (uint8_t)(level * (PATH - 2) + 0.5f);
  for (uint8_t s = 0; s < steps; s++) {
    uint32_t c = noteColour(midi, s == steps - 1);
    strip.setPixelColor(rightPath(s), c);
    strip.setPixelColor(leftPath(s), c);
  }
}

// ---------------------------------------------------------------------
// Buzzer

static void buzzerOff() {
  if (!BUZZER_FITTED) return;
  noTone(BUZZER_PIN);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, BUZZER_IDLE_HIGH ? HIGH : LOW);
}

static void buzzerNote(uint8_t midi) {
  if (!BUZZER_FITTED || !sound || !midi) return;
  int m = midi + 12 * BUZZER_OCTAVE;
  tone(BUZZER_PIN, (unsigned int)(440.0f * powf(2.0f, (m - 69) / 12.0f)));
}

// ---------------------------------------------------------------------
// Game control

static const QuizTune &current() { return QUIZ_TUNES[order[pos]]; }

static void stopPlaying() {
  playing = false;
  buzzerOff();
  strip.clear();
}

void quizStart(uint8_t set) {
  stopPlaying();
  quizSet = set;
  orderCount = 0;
  uint8_t want = (set == QUIZ_CAROL) ? 0 : 1;
  for (uint8_t i = 0; i < QUIZ_TUNE_COUNT && orderCount < sizeof(order); i++) {
    if (QUIZ_TUNES[i].set == want) order[orderCount++] = i;
  }
  for (int i = orderCount - 1; i > 0; i--) {     // shuffle
    int j = random(i + 1);
    uint8_t t = order[i]; order[i] = order[j]; order[j] = t;
  }
  pos = 0;
  revealed = false;
  Serial.println(set == QUIZ_CAROL ? "Carol quiz started" : "Nursery rhyme quiz started");
  quizStatus();
}

void quizPlay(bool withSound) {
  if (quizSet == QUIZ_NONE || orderCount == 0) return;
  stopPlaying();
  const QuizTune &t = current();
  tuneLo = 127; tuneHi = 0;
  for (uint16_t i = 0; i < t.count; i++) {
    uint8_t m = t.notes[i];
    if (!m) continue;
    if (m < tuneLo) tuneLo = m;
    if (m > tuneHi) tuneHi = m;
  }
  sound = withSound;
  if (withSound) {
    revealed = true;
    Serial.print("Answer: ");
    Serial.println(t.title);
  }
  playing   = true;
  noteIdx   = 0;
  noteStart = millis();
  showNote(t.notes[0]);
  buzzerNote(t.notes[0]);
  quizStatus();
}

void quizNext() {
  if (quizSet == QUIZ_NONE) return;
  stopPlaying();
  pos++;
  if (pos >= orderCount) {                 // all played: new random round
    uint8_t last = order[orderCount - 1];
    quizStart(quizSet);
    if (orderCount > 1 && order[0] == last) { // don't repeat straight away
      uint8_t t = order[0]; order[0] = order[1]; order[1] = t;
    }
    Serial.println("All tunes played - new round");
  }
  revealed = false;
  quizStatus();
}

void quizEnd() {
  if (quizSet == QUIZ_NONE) return;
  stopPlaying();
  quizSet = QUIZ_NONE;
  Serial.println("Quiz ended");
  quizStatus();
}

// Fireplace check: right side red, top green, left side blue, with the first
// light of each side white, so the corners can be checked when fitted.
void fireplaceDraw() {
  for (uint8_t i = 0; i < LED_COUNT; i++) {
    uint32_t c;
    if (i < FIRE_RIGHT)                 c = strip.Color(255, 0, 0);
    else if (i < FIRE_RIGHT + FIRE_TOP) c = strip.Color(0, 255, 0);
    else                                c = strip.Color(0, 0, 255);
    if (i == 0 || i == FIRE_RIGHT || i == FIRE_RIGHT + FIRE_TOP) c = strip.Color(255, 255, 255);
    strip.setPixelColor(i, c);
  }
}

void quizDraw(uint32_t now) {
  if (quizSet == QUIZ_NONE) return;
  if (!playing) {
    // Waiting between tunes: a slow gold glow in the middle of the top.
    strip.clear();
    float wave = 0.5f - 0.5f * cosf((now % 3000) / 3000.0f * 2.0f * (float)PI);
    uint8_t v = 30 + (uint8_t)(120 * wave);
    uint32_t gold = strip.Color(v, v * 2 / 3, 0);
    strip.setPixelColor(rightPath(PATH - 1), gold);
    strip.setPixelColor(leftPath(PATH - 1), gold);
    return;
  }

  const QuizTune &t = current();
  uint32_t len = (uint32_t)t.durs[noteIdx] * t.ms16;
  uint32_t gap = len * 12 / 100;
  if (gap < 25) gap = 25;
  if (gap > 120) gap = 120;
  uint32_t el = now - noteStart;

  if (el >= len) {                         // next note
    noteIdx++;
    if (noteIdx >= t.count) {
      stopPlaying();
      quizStatus();
      return;
    }
    noteStart += len;
    showNote(t.notes[noteIdx]);
    buzzerNote(t.notes[noteIdx]);
  } else if (el >= len - gap) {            // short gap at the end of each note
    strip.clear();
    buzzerOff();
  }
}

void quizStatus() {
  if (quizSet == QUIZ_NONE) {
    bleSetQuizStatus("Q0");
    return;
  }
  // e.g. "Q1 3/12 T5 P1 R0": set, tune number, tune id, playing, revealed
  String s = "Q" + String(quizSet) + " " + String(pos + 1) + "/" + String(orderCount) +
             " T" + String(order[pos]) + " P" + String(playing ? 1 : 0) +
             " R" + String(revealed ? 1 : 0);
  bleSetQuizStatus(s);
  Serial.print(quizSet == QUIZ_CAROL ? "Carol quiz: tune " : "Nursery quiz: tune ");
  Serial.print(pos + 1);
  Serial.print(" of ");
  Serial.print(orderCount);
  Serial.println(playing ? " (playing)" : "");
}
