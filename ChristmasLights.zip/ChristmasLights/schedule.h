// Christmas Lights - clock and daily timer helpers
#pragma once
#include <Arduino.h>

// Set the clock from the phone (seconds since 1 Jan 1970, GMT).
void scheduleSetClock(uint32_t epochSeconds);

// True once the phone has set the clock since power-on.
bool scheduleClockSet();

// Current time as minutes since midnight GMT (0-1439).
uint16_t scheduleMinuteOfDay();

// Should the lights be on at nowMin, for a timer running onMin -> offMin?
// Handles overnight timers (e.g. on 18:00, off 01:00).
bool scheduleWantsOn(uint16_t onMin, uint16_t offMin, uint16_t nowMin);
