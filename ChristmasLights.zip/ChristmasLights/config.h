// Christmas Lights - settings
// Change values here; everything else reads from this file.
#pragma once
#include <Arduino.h>
#include <Adafruit_NeoPixel.h>

// ---- LED string ----
const int LED_PIN   = 0;    // GP0 = physical pin 1
const int LED_COUNT = 50;   // Pimoroni 5 m RGB LED Wire (copper version)
#define LED_TYPE (NEO_GRB + NEO_KHZ800)   // colour order confirmed GRB

// ---- Bluetooth ----
// The name the phone sees when it looks for the lights.
const char *const BT_NAME = "Christmas Lights";

// ---- Mode button (optional) ----
// Button between this pin and GND steps to the next energy level.
// Safe to leave unconnected.
const int BUTTON_PIN = 20;  // GP20 = physical pin 26

// ---- Brightness ----
// The cap is the brightest the lights will ever go (0-255).
//   25  = about 10%, safe when powered from the PC's USB port
//   102 = about 40%, use once the external 5 V supply is connected
const uint8_t BRIGHTNESS_CAP = 25;
const uint8_t DEFAULT_BRIGHTNESS_PCT = 100;  // percent of the cap at start-up

// ---- Timing ----
const uint32_t FRAME_MS       = 33;      // about 30 frames per second
const uint32_t AUTO_ROTATE_MS = 60000;   // change effect every 60 s in auto mode

// ---- Timer defaults (GMT, used until changed from the phone) ----
const uint16_t DEFAULT_ON_MIN  = 16 * 60;   // 4 pm
const uint16_t DEFAULT_OFF_MIN = 23 * 60;   // 11 pm

// ---- Fireplace layout (used by the music quiz) ----
// The string starts at the bottom RIGHT, goes up the right side, across the
// top, and down the left side. Change these if the corners land in the wrong
// place when fitted (send 'f' to show each side in its own colour).
// The three numbers must add up to LED_COUNT.
const uint8_t FIRE_RIGHT = 17;   // LEDs up the right side
const uint8_t FIRE_TOP   = 16;   // LEDs across the top
const uint8_t FIRE_LEFT  = 17;   // LEDs down the left side

// ---- Buzzer (optional, used by the music quiz on Reveal) ----
// Leave BUZZER_FITTED false until a working buzzer is connected; the phone
// plays the tune instead. Labels are as printed on the breadboard (GP numbers).
const bool    BUZZER_FITTED    = true;
const int     BUZZER_PIN       = 14;     // breadboard label 14 (GP14)
const bool    BUZZER_IDLE_HIGH = false;  // true for "low level trigger" modules
const int8_t  BUZZER_OCTAVE    = 1;      // 1 = play an octave higher (louder on a piezo); 0 = as written

// ---- Saved settings ----
// Changes are saved to flash a few seconds after the last command, so a
// burst of button presses only causes one write.
const uint32_t SAVE_DELAY_MS = 5000;
