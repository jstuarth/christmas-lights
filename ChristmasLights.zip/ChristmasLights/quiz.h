// Christmas Lights - music quiz and fireplace check
#pragma once
#include <Arduino.h>

// Quiz sets
const uint8_t QUIZ_NONE    = 0;
const uint8_t QUIZ_CAROL   = 1;
const uint8_t QUIZ_NURSERY = 2;

void quizStart(uint8_t set);      // shuffle that set's tunes and wait at tune 1
void quizPlay(bool withSound);    // play the current tune (lights; buzzer if withSound)
void quizNext();                  // move to the next tune (reshuffles after the last)
void quizEnd();                   // stop the quiz (the main sketch picks the next mode)

void quizDraw(uint32_t now);      // draw one quiz frame (call ~30 times a second)
void fireplaceDraw();             // each side of the fireplace in its own colour
void quizStatus();                // print status and send it to the phone
