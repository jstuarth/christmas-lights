// Christmas Lights - Bluetooth control
//
// One Bluetooth service with four characteristics:
//   Command (write)       - text commands, the same as the Serial Monitor
//   Status  (read/notify) - display state, e.g. "L3 E2 A1 B100 O1"
//                           L level, E effect, A auto (1/0),
//                           B brightness %, O lights on (1/0)
//   Timer   (read/notify) - timer state, e.g. "T1 C1 1600 2300"
//                           T timer enabled (1/0), C clock set (1/0),
//                           then on time and off time (HHMM, GMT)
//   Quiz    (read/notify) - music quiz state, e.g. "Q1 3/12 T5 P1 R0"
//                           Q set (0 none, 1 carols, 2 nursery), tune number,
//                           T tune id, P playing (1/0), R revealed (1/0)

#include <BLE.h>
#include "ble_control.h"
#include "config.h"

// Unique IDs for this project. The phone page uses the same ones.
static const char *SERVICE_UUID = "13a56b22-77de-41c9-abfe-b04a3232e036";
static const char *COMMAND_UUID = "9b9c8ef6-6d34-43e0-a057-83a3534036bf";
static const char *STATUS_UUID  = "b1006b19-b5bd-413d-ad24-2c93dbbc0697";
static const char *TIMER_UUID   = "5d3e9a71-0c84-4b6f-9e2a-7f1c6b8d4e20";
static const char *QUIZ_UUID    = "3344eadc-34d4-4bd6-89ae-b9407980f1ae";

static BLECharacteristic *commandChar = nullptr;
static BLECharacteristic *statusChar  = nullptr;
static BLECharacteristic *timerChar   = nullptr;
static BLECharacteristic *quizChar    = nullptr;

// Commands arrive in the background, so they are queued here and the
// main loop picks them up safely.
static const uint8_t QUEUE_SIZE = 64;
static volatile char    queue[QUEUE_SIZE];
static volatile uint8_t head = 0;
static volatile uint8_t tail = 0;

static void onCommandWrite(BLECharacteristic *c) {
  const char *data = (const char *)c->valueData();
  size_t len = c->valueLen();
  for (size_t i = 0; i < len; i++) {
    uint8_t next = (head + 1) % QUEUE_SIZE;
    if (next == tail) break;          // queue full: drop the rest
    queue[head] = data[i];
    head = next;
  }
}

bool bleReadCommand(char &c) {
  if (tail == head) return false;
  c = queue[tail];
  tail = (tail + 1) % QUEUE_SIZE;
  return true;
}

void bleSetStatus(const String &status) {
  if (statusChar) statusChar->setValue(status);
}

void bleSetTimerStatus(const String &status) {
  if (timerChar) timerChar->setValue(status);
}

void bleSetQuizStatus(const String &status) {
  if (quizChar) quizChar->setValue(status);
}

void bleSetup() {
  BLE.begin(BT_NAME);

  BLEService *service = new BLEService(BLEUUID(SERVICE_UUID));

  commandChar = new BLECharacteristic(BLEUUID(COMMAND_UUID),
                                      BLEWrite | BLEWriteWithoutResponse,
                                      "Command");
  commandChar->onWrite(onCommandWrite);

  statusChar = new BLECharacteristic(BLEUUID(STATUS_UUID),
                                     BLERead | BLENotify,
                                     "Status");
  statusChar->setValue(String("Starting"));

  timerChar = new BLECharacteristic(BLEUUID(TIMER_UUID),
                                    BLERead | BLENotify,
                                    "Timer");
  timerChar->setValue(String("Starting"));

  service->addCharacteristic(commandChar);
  service->addCharacteristic(statusChar);
  quizChar = new BLECharacteristic(BLEUUID(QUIZ_UUID),
                                   BLERead | BLENotify,
                                   "Quiz");
  quizChar->setValue(String("Q0"));

  service->addCharacteristic(timerChar);
  service->addCharacteristic(quizChar);
  BLE.server()->addService(service);

  // Advertise the name only; the full service ID won't fit alongside it.
  BLE.startAdvertising(false);
}
