// Christmas Lights - clock and daily timer helpers
//
// The Pico has no battery-backed clock, so the phone sends the time each
// time it connects. Between connections the Pico counts forward from that.
// Times are GMT only (winter use).

#include "schedule.h"

static bool     clockSet   = false;
static uint32_t baseEpoch  = 0;   // time the phone sent
static uint32_t baseMillis = 0;   // millis() when it arrived

void scheduleSetClock(uint32_t epochSeconds) {
  baseEpoch  = epochSeconds;
  baseMillis = millis();
  clockSet   = true;
}

bool scheduleClockSet() {
  return clockSet;
}

uint16_t scheduleMinuteOfDay() {
  uint32_t now = baseEpoch + (millis() - baseMillis) / 1000;
  return (now % 86400UL) / 60;
}

bool scheduleWantsOn(uint16_t onMin, uint16_t offMin, uint16_t nowMin) {
  if (onMin < offMin) return nowMin >= onMin && nowMin < offMin;   // same day
  return nowMin >= onMin || nowMin < offMin;                       // overnight
}
