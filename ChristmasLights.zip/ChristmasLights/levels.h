// Christmas Lights - energy levels
// This table defines every level and which effects belong to it.
// To add a level, add a new effect list and a new line in LEVELS.
// To move an effect, move its line to another list.
#pragma once
#include "effects.h"

struct Effect {
  const char* name;
  EffectFn    draw;
};

struct Level {
  const char*   name;
  const Effect* effects;
  uint8_t       count;
};

#define COUNT_OF(a) (sizeof(a) / sizeof((a)[0]))

static const Effect LEVEL1_CALM[] = {
  { "Steady warm white",    fxSteadyWarm },
  { "Breathing warm white", fxBreatheWarm },
};

static const Effect LEVEL2_GENTLE[] = {
  { "Slow red/green/gold fade", fxSlowFade },
  { "Gentle twinkle",           fxGentleTwinkle },
};

static const Effect LEVEL3_FESTIVE[] = {
  { "Candy cane",           fxCandyCane },
  { "Colour wipe",          fxColourWipe },
  { "Traditional multicolour", fxTraditional },
};

static const Effect LEVEL4_LIVELY[] = {
  { "Rainbow cycle",        fxRainbowCycle },
  { "Fast sparkle",         fxFastSparkle },
  { "Red/green flash",      fxRedGreenFlash },
};

static const Effect LEVEL5_PARTY[] = {
  { "Rainbow chase",        fxRainbowChase },
  { "Confetti",             fxConfetti },
  { "Fire",                 fxFire },
};

static const Level LEVELS[] = {
  { "Calm",    LEVEL1_CALM,    COUNT_OF(LEVEL1_CALM) },
  { "Gentle",  LEVEL2_GENTLE,  COUNT_OF(LEVEL2_GENTLE) },
  { "Festive", LEVEL3_FESTIVE, COUNT_OF(LEVEL3_FESTIVE) },
  { "Lively",  LEVEL4_LIVELY,  COUNT_OF(LEVEL4_LIVELY) },
  { "Party",   LEVEL5_PARTY,   COUNT_OF(LEVEL5_PARTY) },
};

static const uint8_t LEVEL_COUNT = COUNT_OF(LEVELS);
