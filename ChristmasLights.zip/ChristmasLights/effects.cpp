// Christmas Lights - display effects
// One function per effect. Each draws a single frame; the main loop calls
// it about 30 times a second and then shows the result.

#include "effects.h"
#include "config.h"
#include <math.h>
#include <string.h>

// ---------- colours ----------
static uint32_t rgb(uint8_t r, uint8_t g, uint8_t b) {
  return Adafruit_NeoPixel::Color(r, g, b);
}
static const uint32_t WARM   = rgb(255, 120, 30);
static const uint32_t RED    = rgb(255, 0, 0);
static const uint32_t GREEN  = rgb(0, 255, 0);
static const uint32_t BLUE   = rgb(0, 0, 255);
static const uint32_t GOLD   = rgb(255, 170, 0);
static const uint32_t ORANGE = rgb(255, 80, 0);
static const uint32_t PURPLE = rgb(150, 0, 255);
static const uint32_t WHITE  = rgb(255, 255, 255);

// ---------- helpers ----------
// Scale a colour's brightness: level 0 (off) to 255 (unchanged).
static uint32_t dim(uint32_t c, uint8_t level) {
  uint8_t r = ((c >> 16) & 0xFF) * level / 255;
  uint8_t g = ((c >> 8) & 0xFF) * level / 255;
  uint8_t b = (c & 0xFF) * level / 255;
  return rgb(r, g, b);
}

// Mix two colours: amount 0 = all a, 255 = all b.
static uint32_t blend(uint32_t a, uint32_t b, uint8_t amount) {
  uint8_t r = (((a >> 16) & 0xFF) * (255 - amount) + ((b >> 16) & 0xFF) * amount) / 255;
  uint8_t g = (((a >> 8) & 0xFF) * (255 - amount) + ((b >> 8) & 0xFF) * amount) / 255;
  uint8_t bl = ((a & 0xFF) * (255 - amount) + (b & 0xFF) * amount) / 255;
  return rgb(r, g, bl);
}

// Rainbow colour from a hue (0-65535), gamma-corrected so it looks even.
static uint32_t hue(uint16_t h) {
  return strip.gamma32(strip.ColorHSV(h));
}

// =====================================================================
// Level 1 - Calm
// =====================================================================

// Steady warm white.
void fxSteadyWarm(uint32_t t, bool start) {
  strip.fill(WARM);
}

// Warm white slowly brightening and dimming, one breath every 6 seconds.
void fxBreatheWarm(uint32_t t, bool start) {
  float phase = (t % 6000) / 6000.0f;
  float wave = 0.5f - 0.5f * cosf(phase * 2.0f * (float)PI);  // 0..1
  uint8_t level = 40 + (uint8_t)(215.0f * wave);
  strip.fill(dim(WARM, level));
}

// =====================================================================
// Level 2 - Gentle
// =====================================================================

// Whole string fades slowly red -> green -> gold, 4 seconds per fade.
void fxSlowFade(uint32_t t, bool start) {
  static const uint32_t cols[] = { RED, GREEN, GOLD };
  const uint32_t fadeMs = 4000;
  uint8_t seg = (t / fadeMs) % 3;
  uint8_t amount = (t % fadeMs) * 255 / fadeMs;
  strip.fill(blend(cols[seg], cols[(seg + 1) % 3], amount));
}

// Dim warm white with random LEDs gently glowing brighter and fading back.
void fxGentleTwinkle(uint32_t t, bool start) {
  static uint16_t twinkle[LED_COUNT];   // 0 = idle, otherwise progress 1..511
  if (start) memset(twinkle, 0, sizeof(twinkle));

  if (random(8) == 0) {                 // occasionally start a new twinkle
    int p = random(LED_COUNT);
    if (twinkle[p] == 0) twinkle[p] = 1;
  }

  for (int i = 0; i < LED_COUNT; i++) {
    uint8_t level = 60;
    if (twinkle[i]) {
      uint16_t x = twinkle[i];
      uint16_t rise = (x < 256) ? x : 511 - x;   // up then down
      level = 60 + rise * 195 / 255;
      twinkle[i] += 4;
      if (twinkle[i] >= 512) twinkle[i] = 0;
    }
    strip.setPixelColor(i, dim(WARM, level));
  }
}

// =====================================================================
// Level 3 - Festive
// =====================================================================

// Red and white stripes moving along the string.
void fxCandyCane(uint32_t t, bool start) {
  const int band = 4;
  uint32_t offset = t / 150;
  for (int i = 0; i < LED_COUNT; i++) {
    bool white = ((i + offset) / band) % 2;
    strip.setPixelColor(i, white ? dim(WHITE, 200) : RED);
  }
}

// Each new colour sweeps along the string over the previous one.
void fxColourWipe(uint32_t t, bool start) {
  static const uint32_t cols[] = { RED, GREEN, BLUE, GOLD, PURPLE };
  const int n = sizeof(cols) / sizeof(cols[0]);
  uint32_t step = t / 60;
  int current = (step / LED_COUNT) % n;
  int previous = (current + n - 1) % n;
  int pos = step % LED_COUNT;
  for (int i = 0; i < LED_COUNT; i++) {
    strip.setPixelColor(i, i <= pos ? cols[current] : cols[previous]);
  }
}

// Traditional multicolour bulbs, pattern shifting along once a second.
void fxTraditional(uint32_t t, bool start) {
  static const uint32_t cols[] = { RED, GREEN, BLUE, ORANGE, PURPLE };
  const int n = sizeof(cols) / sizeof(cols[0]);
  uint32_t shift = t / 1000;
  for (int i = 0; i < LED_COUNT; i++) {
    strip.setPixelColor(i, cols[(i + shift) % n]);
  }
}

// =====================================================================
// Level 4 - Lively
// =====================================================================

// Full rainbow spread along the string, rotating every 5 seconds.
void fxRainbowCycle(uint32_t t, bool start) {
  uint32_t base = (t % 5000) * 65536UL / 5000;
  for (int i = 0; i < LED_COUNT; i++) {
    strip.setPixelColor(i, hue(base + (uint32_t)i * 65536UL / LED_COUNT));
  }
}

// Deep blue background with bright white sparkles.
void fxFastSparkle(uint32_t t, bool start) {
  strip.fill(dim(BLUE, 40));
  for (int k = 0; k < 4; k++) {
    strip.setPixelColor(random(LED_COUNT), WHITE);
  }
}

// Alternate LEDs red and green, swapping every 0.4 seconds.
void fxRedGreenFlash(uint32_t t, bool start) {
  int phase = (t / 400) % 2;
  for (int i = 0; i < LED_COUNT; i++) {
    strip.setPixelColor(i, (i % 2 == phase) ? RED : GREEN);
  }
}

// =====================================================================
// Level 5 - Party
// =====================================================================

// Every third LED lit in rainbow colours, racing along the string.
void fxRainbowChase(uint32_t t, bool start) {
  uint32_t step = t / 80;
  for (int i = 0; i < LED_COUNT; i++) {
    if ((i + step) % 3 == 0) {
      strip.setPixelColor(i, hue(step * 1024 + (uint32_t)i * 65536UL / LED_COUNT));
    } else {
      strip.setPixelColor(i, 0);
    }
  }
}

// Random bursts of colour that pop on and fade away.
void fxConfetti(uint32_t t, bool start) {
  static uint32_t buf[LED_COUNT];
  if (start) memset(buf, 0, sizeof(buf));

  for (int i = 0; i < LED_COUNT; i++) buf[i] = dim(buf[i], 215);   // fade
  for (int k = 0; k < 2; k++) buf[random(LED_COUNT)] = hue(random(65536));

  for (int i = 0; i < LED_COUNT; i++) strip.setPixelColor(i, buf[i]);
}

// Flickering firelight in reds and oranges.
void fxFire(uint32_t t, bool start) {
  static uint8_t heat[LED_COUNT];
  if (start) memset(heat, 150, sizeof(heat));

  for (int i = 0; i < LED_COUNT; i++) {
    heat[i] = (heat[i] * 3 + random(60, 256)) / 4;             // drift randomly
    uint8_t g = map(heat[i], 60, 255, 10, 110);                // hotter = more orange
    strip.setPixelColor(i, dim(rgb(255, g, 0), heat[i]));
  }
}
