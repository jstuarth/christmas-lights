// Christmas Lights - modes, timer, saved settings and music quiz
// Board:   Raspberry Pi Pico 2W (Earle Philhower Arduino-Pico core)
// Library: Adafruit NeoPixel
// Tools > IP/Bluetooth Stack must include "Bluetooth".
//
// The lights are always in exactly one MODE. Choosing a mode switches to it
// straight away, whatever was running before.
//
// Commands come from the Serial Monitor (115200 baud) or from the phone page
// over Bluetooth (device name "Christmas Lights"):
//
//   Modes
//     e   One effect     stays on one effect
//     a   Auto           changes effect every minute, within the energy level
//     s   Shuffle all    every effect from every level in random order
//     f   Fireplace      right side red, top green, left side blue
//     C   Carol quiz     N   Nursery rhyme quiz
//     o   Off
//
//   In One effect / Auto / Shuffle all
//     1-5 choose energy level        n   next effect
//
//   In a quiz
//     p   play the tune (lights only)
//     r   reveal: play it again with sound (buzzer, if fitted)
//     x   next tune
//
//   Settings
//     +  -          brighter / dimmer
//     t             timer on/off
//     S16002300;    set timer: on 16:00, off 23:00 (GMT)
//     T<seconds>;   set the clock (the phone page does this automatically)
//     ?             show help and current status
//
// An optional push button on GP20 to GND steps to the next energy level.

#include <Adafruit_NeoPixel.h>
#include <EEPROM.h>
#include "config.h"
#include "effects.h"
#include "levels.h"
#include "ble_control.h"
#include "schedule.h"
#include "quiz.h"

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, LED_TYPE);

// ---- modes ----
enum Mode : uint8_t {
  MODE_EFFECT = 0,   // one effect
  MODE_AUTO,         // auto-rotate within the level
  MODE_SHUFFLE,      // all effects, random order
  MODE_FIRE,         // fireplace check
  MODE_CAROL,        // carol quiz
  MODE_NURSERY,      // nursery rhyme quiz
  MODE_OFF,
  MODE_COUNT
};
const char *const MODE_NAMES[MODE_COUNT] = {
  "One effect", "Auto", "Shuffle all", "Fireplace check",
  "Carol quiz", "Nursery rhyme quiz", "Off"
};

Mode     mode          = MODE_AUTO;
Mode     lastLitMode   = MODE_AUTO;      // effect, auto or shuffle: where the timer returns to

// ---- current state ----
uint8_t  currentLevel  = 0;      // index into LEVELS (0 = level 1)
uint8_t  currentEffect = 0;      // index into that level's effects
uint8_t  brightnessPct = DEFAULT_BRIGHTNESS_PCT;  // percent of BRIGHTNESS_CAP

bool     timerEnabled  = true;
uint16_t onMin         = DEFAULT_ON_MIN;   // minutes since midnight GMT
uint16_t offMin        = DEFAULT_OFF_MIN;
bool     timerPrimed   = false;  // has the timer applied its current state yet?
bool     timerWanted   = false;  // what the timer last asked for
uint32_t lastTimerCheck = 0;

uint32_t effectStart   = 0;
bool     firstFrame    = true;
uint32_t lastFrame     = 0;
bool     lastButton    = HIGH;

bool     saveNeeded    = false;
uint32_t changedAt     = 0;

// Shuffle all: a shuffled list of every (level, effect) pair.
// Each effect plays once before the list is reshuffled.
const uint8_t MAX_EFFECTS = 64;
uint8_t  bagLevel[MAX_EFFECTS];
uint8_t  bagEffect[MAX_EFFECTS];
uint8_t  bagSize       = 0;
uint8_t  bagPos        = 0;

// Command arguments (for S and T commands)
char     argCmd        = 0;
char     argBuf[16];
uint8_t  argLen        = 0;

bool isLitMode(Mode m)  { return m == MODE_EFFECT || m == MODE_AUTO || m == MODE_SHUFFLE; }
bool isQuizMode(Mode m) { return m == MODE_CAROL || m == MODE_NURSERY; }

// ---------------------------------------------------------------------
// Saved settings (flash)
// ---------------------------------------------------------------------

struct SavedSettings {
  uint32_t magic;          // marks valid data
  uint8_t  level;
  uint8_t  effect;
  uint8_t  brightnessPct;
  uint8_t  timerEnabled;
  uint16_t onMin;
  uint16_t offMin;
  uint8_t  mode;           // effect, auto, shuffle or off (quizzes aren't saved)
  uint8_t  lastLitMode;
};
const uint32_t SETTINGS_MAGIC = 0x584D4155;  // change to reset saved settings

void loadSettings() {
  SavedSettings s;
  EEPROM.get(0, s);
  if (s.magic != SETTINGS_MAGIC) {
    Serial.println("No saved settings - using defaults");
    return;
  }
  if (s.level < LEVEL_COUNT) {
    currentLevel = s.level;
    if (s.effect < LEVELS[currentLevel].count) currentEffect = s.effect;
  }
  if (s.brightnessPct >= 10 && s.brightnessPct <= 100) brightnessPct = s.brightnessPct;
  timerEnabled = s.timerEnabled;
  if (s.onMin < 1440 && s.offMin < 1440) { onMin = s.onMin; offMin = s.offMin; }
  if (isLitMode((Mode)s.lastLitMode)) lastLitMode = (Mode)s.lastLitMode;
  if (isLitMode((Mode)s.mode) || s.mode == MODE_OFF) mode = (Mode)s.mode;
  Serial.println("Saved settings restored");
}

void saveSettings() {
  SavedSettings s;
  s.magic         = SETTINGS_MAGIC;
  s.level         = currentLevel;
  s.effect        = currentEffect;
  s.brightnessPct = brightnessPct;
  s.timerEnabled  = timerEnabled;
  s.onMin         = onMin;
  s.offMin        = offMin;
  // A quiz or fireplace check isn't restored after a power cut: come back
  // to the last ordinary mode instead.
  s.mode          = (isLitMode(mode) || mode == MODE_OFF) ? mode : lastLitMode;
  s.lastLitMode   = lastLitMode;
  EEPROM.put(0, s);
  EEPROM.commit();
  Serial.println("Settings saved");
}

// Ask for a save a few seconds from now (see SAVE_DELAY_MS).
void markChanged() {
  saveNeeded = true;
  changedAt  = millis();
}

// ---------------------------------------------------------------------
// Status
// ---------------------------------------------------------------------

void applyBrightness() {
  strip.setBrightness((uint16_t)BRIGHTNESS_CAP * brightnessPct / 100);
}

String hhmm(uint16_t minutes) {
  char buf[5];
  snprintf(buf, sizeof(buf), "%02u%02u", minutes / 60, minutes % 60);
  return String(buf);
}

void printStatus() {
  const Level& lv = LEVELS[currentLevel];
  Serial.print("Mode: ");
  Serial.print(MODE_NAMES[mode]);
  if (isLitMode(mode)) {
    Serial.print("  | Level ");
    Serial.print(currentLevel + 1);
    Serial.print(" (");
    Serial.print(lv.name);
    Serial.print(")  Effect: ");
    Serial.print(lv.effects[currentEffect].name);
  }
  Serial.print("  | Brightness ");
  Serial.print(brightnessPct);
  Serial.println("%");

  Serial.print("Timer ");
  Serial.print(timerEnabled ? "ON" : "OFF");
  Serial.print("  on ");
  Serial.print(hhmm(onMin));
  Serial.print(" off ");
  Serial.print(hhmm(offMin));
  Serial.print(" GMT  | Clock ");
  if (scheduleClockSet()) {
    Serial.println(hhmm(scheduleMinuteOfDay()));
  } else {
    Serial.println("not set (connect the phone)");
  }

  // Short status strings for the phone, e.g. "L3 E2 M1 B100"
  bleSetStatus("L" + String(currentLevel + 1) +
               " E" + String(currentEffect + 1) +
               " M" + String((int)mode) +
               " B" + String(brightnessPct));
  bleSetTimerStatus("T" + String(timerEnabled ? 1 : 0) +
                    " C" + String(scheduleClockSet() ? 1 : 0) +
                    " " + hhmm(onMin) + " " + hhmm(offMin));
}

void printHelp() {
  Serial.println();
  Serial.println("Christmas Lights - commands:");
  Serial.println("  Modes: e one effect  a auto  s shuffle all  f fireplace");
  Serial.println("         C carol quiz  N nursery quiz  o off");
  Serial.print("  1-");
  Serial.print(LEVEL_COUNT);
  Serial.println(" energy level     n  next effect");
  Serial.println("  Quiz:  p play  r reveal  x next tune");
  Serial.println("  +  -  brighter / dimmer     t  timer on/off");
  Serial.println("  S16002300;  set timer on 16:00, off 23:00 (GMT)");
  Serial.println("  ?    this help");
  printStatus();
}

void selectEffect(uint8_t level, uint8_t effect) {
  currentLevel  = level % LEVEL_COUNT;
  currentEffect = effect % LEVELS[currentLevel].count;
  effectStart   = millis();
  firstFrame    = true;
  printStatus();
}

// Fill the list with every effect from every level, then shuffle it.
void refillBag() {
  bagSize = 0;
  for (uint8_t l = 0; l < LEVEL_COUNT; l++) {
    for (uint8_t e = 0; e < LEVELS[l].count && bagSize < MAX_EFFECTS; e++) {
      bagLevel[bagSize]  = l;
      bagEffect[bagSize] = e;
      bagSize++;
    }
  }
  for (int i = bagSize - 1; i > 0; i--) {          // Fisher-Yates shuffle
    int j = random(i + 1);
    uint8_t tl = bagLevel[i];  bagLevel[i]  = bagLevel[j];  bagLevel[j]  = tl;
    uint8_t te = bagEffect[i]; bagEffect[i] = bagEffect[j]; bagEffect[j] = te;
  }
  // Don't start the new round with the effect that's showing now
  if (bagSize > 1 && bagLevel[0] == currentLevel && bagEffect[0] == currentEffect) {
    uint8_t tl = bagLevel[0];  bagLevel[0]  = bagLevel[1];  bagLevel[1]  = tl;
    uint8_t te = bagEffect[0]; bagEffect[0] = bagEffect[1]; bagEffect[1] = te;
  }
  bagPos = 0;
}

void shuffleNext() {
  if (bagPos >= bagSize) refillBag();
  uint8_t l = bagLevel[bagPos], e = bagEffect[bagPos];
  bagPos++;
  selectEffect(l, e);
}

// ---------------------------------------------------------------------
// Switching modes
// ---------------------------------------------------------------------

void setMode(Mode m) {
  if (m >= MODE_COUNT) return;
  if (m == mode && isQuizMode(m)) return;   // tapping the running quiz again does nothing

  if (isQuizMode(mode)) quizEnd();          // leaving a quiz
  mode = m;
  if (isLitMode(m)) lastLitMode = m;

  strip.clear();
  switch (m) {
    case MODE_SHUFFLE: bagPos = bagSize = 0; shuffleNext(); break;
    case MODE_CAROL:   quizStart(QUIZ_CAROL); printStatus(); break;
    case MODE_NURSERY: quizStart(QUIZ_NURSERY); printStatus(); break;
    default:           selectEffect(currentLevel, currentEffect); break;
  }
  if (!isQuizMode(m)) quizStatus();         // tells the phone no quiz is running
  markChanged();
}

// ---------------------------------------------------------------------
// Timer
// ---------------------------------------------------------------------

// Called about once a second. The timer only acts when the schedule changes
// (e.g. at 16:00 and 23:00), so choosing a mode by hand lasts until the next
// scheduled change. At "off" time it switches to Off, at "on" time it goes
// back to the last ordinary mode. A quiz in progress is left alone.
void checkTimer() {
  if (!timerEnabled || !scheduleClockSet() || onMin == offMin) {
    timerPrimed = false;
    return;
  }
  bool want = scheduleWantsOn(onMin, offMin, scheduleMinuteOfDay());
  if (!timerPrimed || want != timerWanted) {
    timerPrimed = true;
    timerWanted = want;
    if (want && mode == MODE_OFF) {
      Serial.println("Timer: lights ON");
      setMode(lastLitMode);
    } else if (!want && mode != MODE_OFF && !isQuizMode(mode)) {
      Serial.println("Timer: lights OFF");
      setMode(MODE_OFF);
    }
    printStatus();
  }
}

// ---------------------------------------------------------------------
// Commands
// ---------------------------------------------------------------------

// Commands with a number after them: S (set timer) and T (set clock).
void runArgCommand(char cmd, const char *arg) {
  if (cmd == 'T') {
    uint32_t epoch = strtoul(arg, nullptr, 10);
    if (epoch < 1600000000UL) return;           // not a sensible time
    bool wasSet = scheduleClockSet();
    scheduleSetClock(epoch);
    if (!wasSet) timerPrimed = false;           // first time: apply the timer now
    printStatus();
  } else if (cmd == 'S') {
    if (strlen(arg) != 8) { Serial.println("Timer format: S16002300;"); return; }
    uint16_t h1 = (arg[0] - '0') * 10 + (arg[1] - '0');
    uint16_t m1 = (arg[2] - '0') * 10 + (arg[3] - '0');
    uint16_t h2 = (arg[4] - '0') * 10 + (arg[5] - '0');
    uint16_t m2 = (arg[6] - '0') * 10 + (arg[7] - '0');
    if (h1 > 23 || m1 > 59 || h2 > 23 || m2 > 59) { Serial.println("Invalid time"); return; }
    onMin  = h1 * 60 + m1;
    offMin = h2 * 60 + m2;
    timerPrimed = false;                        // apply the new times now
    markChanged();
    printStatus();
  }
}

// Carry out one command character, from Serial or Bluetooth.
void handleCommand(char c) {
  // Collecting the digits of an S or T command?
  if (argCmd) {
    if (c >= '0' && c <= '9' && argLen < sizeof(argBuf) - 1) {
      argBuf[argLen++] = c;
      return;
    }
    argBuf[argLen] = 0;
    char cmd = argCmd;
    argCmd = 0;
    runArgCommand(cmd, argBuf);
    if (c == ';' || c == '\n' || c == '\r') return;
    // otherwise carry on and treat c as a new command
  }

  switch (c) {
    case 'S': case 'T': argCmd = c; argLen = 0; break;

    // modes
    case 'e': setMode(MODE_EFFECT);  break;
    case 'a': setMode(MODE_AUTO);    break;
    case 's': setMode(MODE_SHUFFLE); break;
    case 'f': setMode(MODE_FIRE);    break;
    case 'C': setMode(MODE_CAROL);   break;
    case 'N': setMode(MODE_NURSERY); break;
    case 'o': setMode(MODE_OFF);     break;

    // effects
    case 'n':
      if (mode == MODE_SHUFFLE) shuffleNext();
      else if (isLitMode(mode)) selectEffect(currentLevel, currentEffect + 1);
      markChanged();
      break;

    // quiz
    case 'p': if (isQuizMode(mode)) quizPlay(false); break;
    case 'r': if (isQuizMode(mode)) quizPlay(true);  break;
    case 'x': if (isQuizMode(mode)) quizNext();      break;

    // settings
    case '+':
      brightnessPct = min(100, brightnessPct + 10);
      applyBrightness(); markChanged(); printStatus();
      break;
    case '-':
      brightnessPct = max(10, brightnessPct - 10);
      applyBrightness(); markChanged(); printStatus();
      break;
    case 't':
      timerEnabled = !timerEnabled;
      timerPrimed = false;                      // apply the timer now if switched on
      markChanged(); printStatus();
      break;
    case '?': printHelp(); break;

    default:
      if (c >= '1' && c <= '9') {               // energy level
        uint8_t level = c - '1';
        if (level >= LEVEL_COUNT) { Serial.println("No such level"); break; }
        currentLevel = level;
        currentEffect = 0;
        // Choosing a level means "show me this level": stay in One effect or
        // Auto if already there, otherwise switch to Auto.
        if (mode == MODE_EFFECT || mode == MODE_AUTO) selectEffect(level, 0);
        else setMode(MODE_AUTO);
        markChanged();
      }
      // anything else (including Enter) is ignored
      break;
  }
}

void handleInput() {
  while (Serial.available()) handleCommand(Serial.read());
  char c;
  while (bleReadCommand(c)) handleCommand(c);
}

void handleButton() {
  bool button = digitalRead(BUTTON_PIN);
  if (button != lastButton) {
    delay(20);  // debounce
    button = digitalRead(BUTTON_PIN);
    if (button != lastButton) {
      lastButton = button;
      if (button == LOW) handleCommand('1' + (currentLevel + 1) % LEVEL_COUNT);   // next level
    }
  }
}

// ---------------------------------------------------------------------

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  EEPROM.begin(256);
  loadSettings();

  strip.begin();
  applyBrightness();
  strip.clear();
  strip.show();

  bleSetup();

  randomSeed(rp2040.hwrand32());
  delay(1500);          // give the Serial Monitor a moment to connect
  printHelp();
  quizStatus();
  if (mode == MODE_SHUFFLE) shuffleNext();
  else selectEffect(currentLevel, currentEffect);
}

void loop() {
  handleInput();
  handleButton();

  uint32_t now = millis();

  // Daily timer
  if (now - lastTimerCheck >= 1000) {
    lastTimerCheck = now;
    checkTimer();
  }

  // Save settings once things have settled
  if (saveNeeded && now - changedAt >= SAVE_DELAY_MS) {
    saveNeeded = false;
    saveSettings();
  }

  // Change effect every AUTO_ROTATE_MS in Auto and Shuffle all.
  // (Not saved, to avoid wearing out the flash.)
  if (now - effectStart >= AUTO_ROTATE_MS) {
    if (mode == MODE_SHUFFLE) {
      shuffleNext();
    } else if (mode == MODE_AUTO && LEVELS[currentLevel].count > 1) {
      selectEffect(currentLevel, currentEffect + 1);
    }
  }

  // Draw a new frame about 30 times a second
  if (now - lastFrame >= FRAME_MS) {
    lastFrame = now;
    switch (mode) {
      case MODE_EFFECT: case MODE_AUTO: case MODE_SHUFFLE:
        LEVELS[currentLevel].effects[currentEffect].draw(now - effectStart, firstFrame);
        firstFrame = false;
        break;
      case MODE_FIRE:    fireplaceDraw(); break;
      case MODE_CAROL: case MODE_NURSERY: quizDraw(now); break;
      default:           strip.clear(); break;   // Off
    }
    strip.show();
  }
}
