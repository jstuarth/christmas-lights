// Christmas Lights - effect declarations
#pragma once
#include <Adafruit_NeoPixel.h>

extern Adafruit_NeoPixel strip;

// Every effect draws one frame.
//   t     = milliseconds since this effect started
//   start = true on the very first frame (lets an effect reset itself)
typedef void (*EffectFn)(uint32_t t, bool start);

// Level 1 - Calm
void fxSteadyWarm(uint32_t t, bool start);
void fxBreatheWarm(uint32_t t, bool start);

// Level 2 - Gentle
void fxSlowFade(uint32_t t, bool start);
void fxGentleTwinkle(uint32_t t, bool start);

// Level 3 - Festive
void fxCandyCane(uint32_t t, bool start);
void fxColourWipe(uint32_t t, bool start);
void fxTraditional(uint32_t t, bool start);

// Level 4 - Lively
void fxRainbowCycle(uint32_t t, bool start);
void fxFastSparkle(uint32_t t, bool start);
void fxRedGreenFlash(uint32_t t, bool start);

// Level 5 - Party
void fxRainbowChase(uint32_t t, bool start);
void fxConfetti(uint32_t t, bool start);
void fxFire(uint32_t t, bool start);
